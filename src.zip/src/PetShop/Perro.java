public class Perro extends Animal {

    private String color = "";
    private String raza = "";
    private String tipoPelo = "";
    private String tienePedrigree = "" ;

    // Constructor
    public Perro(String sexo, int edad, String codigoEAN, String color, String raza, String tipoPelo, String tienePedrigree ) {
        super(sexo, edad, codigoEAN);
        this.color = color;
        this.raza = raza;
        this.tipoPelo = tipoPelo;
        this.tienePedrigree = tienePedrigree;
    }

    //tipo de comida
    @Override
    public boolean aceptaComida(String comida) {
        return comida.equalsIgnoreCase("carne")
                || comida.equalsIgnoreCase("huesos")
                || comida.equalsIgnoreCase("pienso");
    }

    // Getters y Setters
    public String getColor() {
        return color;
    }
    public void setColor(String color) {
        this.color = color;
    }

    public String getRaza() {
        return raza;
    }
    public void setRaza(String raza) {
        this.raza = raza;
    }

    public String getTipoPelo() {
        return tipoPelo;
    }
    public void setTipoPelo(String tipoPelo) {
        this.tipoPelo = tipoPelo;
    }

    public String getTienePedrigree() {
        return tienePedrigree;
    }
    public void setTienePedrigree(String tienePedrigree) {
        this.tienePedrigree = tienePedrigree;
    }
}
