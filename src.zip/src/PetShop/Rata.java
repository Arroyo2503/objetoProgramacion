public class Rata extends Animal {

    private int peso;
    private int tamaño;

    public Rata(String sexo, int edad, String codigoEAN, int peso, int tamaño) {
        super(sexo, edad, codigoEAN);
        this.peso = peso;
        this.tamaño = tamaño;
    }


    @Override
    public boolean aceptaComida(String comida) {
        System.out.println("Las ratas no tienen comida.");
        return false;
    }


    public void setTamaño(int tamaño) {
        this.tamaño = tamaño;
    }
    public int getTamaño() {
        return tamaño;
    }

    public void setPeso(int peso) {
        this.peso = peso;
    }
    public int getPeso() {
        return peso;
    }
}