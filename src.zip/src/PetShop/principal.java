public class principal {
    public static void main(String[] args) {

                Perro perro = new Perro("Macho", 500, "EAN12345", "Negro", "Labrador", "Corto", "si");
                Gato gato = new Gato("Hembra", 300, "EAN67890", "Blanco", "Persa", "Largo");
                Ave ave = new Ave("Macho", 100, "EAN11223", "Amarillo", "Canario");
                Rata rata = new Rata("Hembra", 200, "EAN44556", 250, 10);

                String comida = "pienso";

                System.out.println("¿El perro acepta " + comida + "? " + (perro.aceptaComida(comida) ? "Sí" : "No"));
                System.out.println("¿El gato acepta " + comida + "? " + (gato.aceptaComida(comida) ? "Sí" : "No"));
                System.out.println("¿El pájaro acepta " + comida + "? " + (ave.aceptaComida(comida) ? "Sí" : "No"));
                System.out.println("¿La rata acepta " + comida + "? " + (rata.aceptaComida(comida) ? "Sí" : "No"));
            }
        }

