public class Venta {

        private Animal animal ;
        private double precio = 0;
        private String nombreDueño = "";
        private String apellidosDueño = "";
        private String dniDueño = "";

        public Venta(Animal animal, double precio, String nombreDueño, String apellidosDueño, String dniDueño) {
            this.animal = animal;
            this.precio = precio;
            this.nombreDueño = nombreDueño;
            this.apellidosDueño = apellidosDueño;
            this.dniDueño = dniDueño;
        }

        public Venta(Animal animal, double precio) {
            this.animal = animal;
            this.precio = precio;
            this.nombreDueño = null;
            this.apellidosDueño = null;
            this.dniDueño = null;
        }

        public Animal getAnimal() {
            return animal;
        }

        public double getPrecio() {
            return precio;
        }

        public String getNombreDueño() {
            return nombreDueño;
        }

        public String getApellidosDueño() {
            return apellidosDueño;
        }

        public String getDniDueño() {
            return dniDueño;
        }
    }



